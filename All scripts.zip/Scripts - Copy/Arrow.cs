﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : MonoBehaviour {

    [Header("References")]
    [SerializeField]
    protected Rigidbody2D _rigidbody;

    [Header("Customisation")]
    [SerializeField]
    private float moveSpeed;

    [Header("Arrow")]
    [SerializeField]
    private float freezeDuration;
    private bool frozen;
    [SerializeField]
    private int damage;

    public float MoveSpeed
    {
        get
        {
            return moveSpeed;
        }

        set
        {
            moveSpeed = value;
        }
    }

    public bool Frozen
    {
        get
        {
            return frozen;
        }

        set
        {
            frozen = value;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Environment"))
        {
            transform.SetParent(collision.transform);
            Freeze();
        }
        else if(collision.gameObject.layer == LayerMask.NameToLayer("Boss"))
        {
            if (frozen == false)
            {
                Boss b = collision.gameObject.GetComponent<ObjectReference>().References[0].GetComponent<Boss>();
                b.TakeDamage(damage);
                transform.SetParent(collision.transform);
                Freeze();
            }
        }
    }

    public void Freeze()
    {
        frozen = true;
        _rigidbody.velocity = Vector2.zero;
        _rigidbody.bodyType = RigidbodyType2D.Static;
        Destroy(gameObject, freezeDuration);
    }

    private void Update()
    {
        if (frozen == false)
        {
            transform.right = new Vector2(_rigidbody.velocity.x, _rigidbody.velocity.y);
        }
    }

    protected virtual void Start()
    {
        _rigidbody.AddRelativeForce(transform.right * moveSpeed * Time.deltaTime);
    }
}
