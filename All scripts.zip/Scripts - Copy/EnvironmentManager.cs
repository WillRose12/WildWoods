﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnvironmentManager : MonoBehaviour {
    public Animator[] bridgeAnims;

    public void CollapseBridges()
    {
        foreach (Animator a in bridgeAnims)
        {
            a.Play("Bridge collapse");
        }
    }
}
