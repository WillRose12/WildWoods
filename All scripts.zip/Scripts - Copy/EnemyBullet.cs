﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : Projectile {

    [SerializeField]
    private int Damage;

    public void OnCollisionEnter2D(Collision2D col)
    {
        if(col.gameObject.layer == LayerMask.NameToLayer("Player")){
            Player p = col.gameObject.GetComponent<Player>();
            p.TakeDamage(Damage);
        }

        Destroy(gameObject);
    }

}
