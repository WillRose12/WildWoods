﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wolf : Boss {

    [Header("Wolf")]
    public SpriteChanger spriteChanger;

    protected override void Flip(bool Toggle)
    {
        if (Toggle == true)
        {
            transform.localScale = new Vector3(-1, 1, 1);
        }
        else
        {
            transform.localScale = new Vector3(1,1,1);
        }
    }

    protected override void OnWaypointExit()
    {
        base.OnWaypointExit();
        spriteChanger.ChangeSprite(0);
    }
}
