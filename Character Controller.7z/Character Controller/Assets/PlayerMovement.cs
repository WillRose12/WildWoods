using UnityEngine;
using UnityEngine.Events;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 40f;
	[SerializeField] private float jumpForce = 400f;
	[SerializeField] private float smoothing = .05f;
	[SerializeField] private bool airControl = false;
	[SerializeField] private Transform groundChecker;
    [SerializeField] private Rigidbody2D _rigidbody;
    [SerializeField] private SpriteRenderer _renderer;

    const float groundCheckRadius = .2f;
	private bool grounded;
	private bool facingRight = true;
	private Vector2 _velocity = Vector2.zero;
    private float horizontalMovement = 0f;
    private bool jump = false;

    private void Update()
    {
        //Get whether the user is pressing the A button or the D button.
        horizontalMovement = Input.GetAxisRaw("Horizontal") * moveSpeed;

        if (Input.GetButton("Jump") && grounded == true)
        {
            grounded = false;
            jump = true;
        }
    }

    private void FixedUpdate()
	{
        //Checking if the player is grounded or not.
		bool wasGrounded = grounded;
		grounded = false;

        Collider2D[] hits = Physics2D.OverlapCircleAll(groundChecker.position, groundCheckRadius);
		for (int i = 0; i < hits.Length; i++)
		{
            if (hits[i].gameObject.layer == LayerMask.NameToLayer("Environment"))
            {
                if (hits[i].gameObject != gameObject)
                {
                    grounded = true;
                }
            }
		}

        //Move the character.
        Move(horizontalMovement * Time.deltaTime, jump);
        jump = false;
    }


	public void Move(float move, bool _jump)
	{
        //Checking that we are allowed to move the character.
		if (grounded == true || airControl == true)
		{
            //Need to get the goal vector that the player will move towards.
			Vector2 goal = new Vector2(move * 10f, _rigidbody.velocity.y);
            //Actually move the player using smooth damp which smoothes out movement using delta time.
			_rigidbody.velocity = Vector2.SmoothDamp(_rigidbody.velocity, goal, ref _velocity, smoothing, 500f, Time.deltaTime);

			if (move > 0 && !facingRight)
			{
				Flip();
			}
			else if (move < 0 && facingRight)
			{
				Flip();
			}
		}

        //Check if the player needs to jump.
		if (grounded && _jump)
		{
			grounded = false;
			_rigidbody.AddForce(new Vector2(0f, jumpForce));
		}
	}


	private void Flip()
	{
		facingRight = !facingRight;

        _renderer.flipX = !_renderer.flipX;
	}
}
