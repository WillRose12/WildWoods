﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : LivingBeing {

    protected override void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("!!!!!");
        base.OnCollisionEnter2D(collision);

        if(collision.gameObject.layer == LayerMask.NameToLayer("Arrow"))
        {
            TakeDamage(20);
        }
    }
}
