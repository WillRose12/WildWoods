﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LivingBeing : MonoBehaviour {

    [Header("Variables")]
    public int startHealth;
    public int currentHealth;

    private void Start()
    {
        currentHealth = startHealth;
    }

    protected virtual void TakeDamage(int amount) {
        currentHealth -= amount;

        if(currentHealth <= 0)
        {
            Die();
        }
    }

    protected virtual void Die()
    {
        Debug.Log("I have died");
    }

    protected virtual void OnCollisionEnter2D(Collision2D collision)
    {
        //Override this method depending on if the inheriting script is player or enemy.
    }
}
