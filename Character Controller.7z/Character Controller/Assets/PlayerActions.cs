﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerActions : MonoBehaviour {

    public enum ShootingType
    {
        Charged,
        Instant,
    }

    [Header("Shooting")]
    public ShootingType shooterType;
    public GameObject bulletPrefab;
    public Transform shootingPosition;

    //Instant shooting
    public float firerate;
    public float fixedPower;
    private float fireCountdown;

    //Charged shooting
    public float maxCharge;
    private float currentCharge;

    public void Update()
    {
        if (shooterType == ShootingType.Instant)
        {
            if (fireCountdown <= 0)
            {
                if (Input.GetMouseButtonDown(0))
                {
                    CreateArrow(25);
                }
            }

            fireCountdown -= Time.deltaTime;
        }

        if (shooterType == ShootingType.Charged)
        {
            if (Input.GetMouseButton(0))
            {
                Charge();
            }
            if (Input.GetMouseButtonUp(0))
            {
                Release();
            }
        }
    }

    public void CreateArrow(float power)
    {
        GameObject arrow = Instantiate(bulletPrefab, shootingPosition.transform.position, Quaternion.identity);
        Vector3 point = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 direction = new Vector2(point.x - arrow.transform.position.x, point.y - arrow.transform.position.y);
        arrow.transform.right = direction;
        fireCountdown = firerate;
        Arrow a = arrow.GetComponent<Arrow>();
        a.MoveSpeed = power;
    }

    public void Charge()
    {
        if (currentCharge < maxCharge)
        {
            currentCharge += Time.deltaTime;
        }
        else
        {
            currentCharge = maxCharge;
        }
        //Insert other charging mechanics here.
    }

    public void Release()
    {
        float percentage = currentCharge / maxCharge * 100;
        float power = percentage / fixedPower;
        CreateArrow(power);
        currentCharge = 0;
        //Insert other release mechanics here.
    }
}
