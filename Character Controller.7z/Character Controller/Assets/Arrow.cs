﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : Projectile {

    [Header("Arrow")]
    [SerializeField]
    private float freezeDuration;
    private bool frozen;

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Environment") || collision.gameObject.layer == LayerMask.NameToLayer("Boss"))
        {
            Freeze();
        }
    }

    private void Freeze()
    {
        frozen = true;
        _rigidbody.velocity = Vector2.zero;
        _rigidbody.bodyType = RigidbodyType2D.Static;
        Destroy(gameObject, freezeDuration);
    }

    private void Update()
    {
        if (frozen == false)
        {
            transform.right = new Vector2(_rigidbody.velocity.x, _rigidbody.velocity.y);
        }
    }
}
