﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {

    [Header("References")]
    [SerializeField]
    protected Rigidbody2D _rigidbody;

    [Header("Customisation")]
    [SerializeField]
    private float moveSpeed;

    public float MoveSpeed
    {
        get
        {
            return moveSpeed;
        }

        set
        {
            moveSpeed = value;
        }
    }

    protected virtual void Start()
    {
        _rigidbody.AddRelativeForce(transform.right * moveSpeed * Time.deltaTime);
    }
}
